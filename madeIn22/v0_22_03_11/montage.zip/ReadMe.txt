MontageRealBot.pdf - монтажкa без
компонентов, которые не нужно монтировать.

MontageTop.pdf и MontageFullBot.pdf - монтажки со всеми компонентами.